function itSelf = pxnew(self, varargin)

% pxnew -- No help available.
% pxnew -- Initializer for the "px" class.
%  pxnew(self, ...) initializes self, a px object,
%   and returns a "reference" to self.  The expected
%   usage is "aPXReference = pxnew(px, ...)".  The
%   additional arguments are expected to be cells
%   that contain lists of field/value pairs, with
%   arbitrary nesting.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 04-Apr-1997 13:04:03.

if nargin < 1, help(mfilename), end

% Do initialization here.

v = unnest(varargin);
for i = 2:2:length(v)
   theField = v(i-1);
   theValue = v(i);
   pxset(self, theField, theValue);
end

% End of initialization.

if nargout > 0, itSelf = px(self); end
