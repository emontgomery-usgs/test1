function [theFile] = history(theFile,thecomment)

%function [theFile] = history(theFile,thecomment)
%appends the history with the comment requested
%will work on any netcdf file that has the 'history' attribute

%Need to make more generic

% Written by Jessica M. Cote
% for the U.S. Geological Survey
% Coastal and Marine Geology Program
% Woods Hole, MA
% http://woodshole.er.usgs.gov/
% Please report bugs to jcote@usgs.gov

%version
%updated 10-Aug-1999 16:20:42
% revised to use lower-case "history" and update creation date
%		attribute as well 03-Aug-2000 Fran Hotchkiss
% updated 28-Dec-2000 09:00:47 - changed format for linefeeds put into functions (ALR)

g=netcdf(theFile,'write');

hist=g.history;
if isempty(hist)
   hist=g.History;
   hist=name(hist,'history');
end   
if isempty(hist)
   hist=g.PROG_CMNT1;
   hist=name(hist,'history');
disp(['Global Attribute "PROG_CMNT1" was changed to "history" in file' theFile]);  
end   

g.history=[thecomment hist(:)];
g.CREATION_DATE = datestr(now,0);
close(g)
