function theResult = PXVerbose

% PXVerbose -- Flag for verbosity.
%  PXVerbose (no argument) returns a flag (0 or 1)
%   that is hard-wired into this routine.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 08-Apr-1997 10:54:50.

% Modify to suit need.

theFlag = 0;   % <=== Set this flag as needed.

theResult = (theFlag ~= 0);
