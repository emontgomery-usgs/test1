function theResult = PXInherit(theObject, theMethod, varargin)

% Inherit -- Inheritance of "px" superclass method.
%  Inherit(theObject, 'theMethod', varargin) calls 'theMethod'
%   of the first-most "px" superclass of theObject, scanning
%   from the top of the struct(theObject).

% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 05-Apr-1997 10:41:00.

if nargin < 3, help(mfilename), return, end

result = [];

theFields = fields(theObject);

for i = 1:length(theFields)
   s = ['theObject.' char(theFields(i))];
   f = eval(s);
   if isa('px')
      t = '';
      if nargout > 0, t = ['result=' t]; end
      t = [t char(theMethod) '(f'];
      for j = 1:length(varargin)
         t = [t ','];
         t = [t 'varargin(' int2str(j) ')'];
      end
      t = [t ');'];
      eval(t);
      s = [s ' = result;'];
      eval(s)
      break
   end
end

if nargout > 0, theResult = result; end
