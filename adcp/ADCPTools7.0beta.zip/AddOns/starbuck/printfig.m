function printfig(varargin)

% printfig -- Print a figure with controls invisible.
%  printfig(f1, f2, ...) prints each of the figures
%   whose handles are given by f1, f2, ...  Existing
%   controls are made invisible during the printing.
 
% Copyright (C) 1998 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 02-Oct-1998 13:22:43.
% Updated    24-Nov-1999 09:55:28.

if nargin < 1, varargin{1} = gcf; end

theFigures = get(0, 'Children');

theFigureHandle = varargin;

for k = 1:length(theFigureHandle)
	f = theFigureHandle{k};
	if ischar(f), f = eval(f); end
	figure(f)
	h = findobj(f, 'Type', 'uicontrol');
	vis = zeros(size(h));
	for i = length(h):-1:1
		if isequal(get(h(i), 'Visible'), 'off')
			h(i) = [];
		end
	end
	if any(h), set(h, 'Visible', 'off'), end
	drawnow
	theHandle = num2str(f, 16);
	if eval(theHandle) == f
		thePrintCommand = ['print -v -f' theHandle];
		oldWarning = warning;
		warning('off')
		eval(thePrintCommand)
		warning('on')
		if any(h), set(h, 'Visible', 'on'); end
		drawnow
	end
end
