function theMenu = PXFSWMenu(self, theMenuName)

% PXFSWMenu -- Install standard menus in the PXFSW.
%  PXFSW(self, theMenuName) installs the standard menus in
%   the PXFSW window associated with self.
%   The default menu-name is '<PXFSW>'.  The PXFSW menu is
%   designed for manipulating various views of the window.
 
% Copyright (C) 1996 Dr. Charles R. Denham, ZYDECO.
% All Rights Reserved.

if nargin < 2, theMenuName = ''; end

if isempty(theMenuName), theMenuName = '<PXFSW>'; end

figure(px(self))

h = [];
h = [h; filemenu(theMenuName)];
h = [h; editmenu('<Edit>')];
h = [h; viewmenu('<View>')];

if nargout > 0, theMenu = h; end
