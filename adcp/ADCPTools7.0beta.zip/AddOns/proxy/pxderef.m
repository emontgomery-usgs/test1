function theObject = PXDeref(thePXReference)

% PXDeref -- De-reference a PXReference.
%  PXDeref(thePXReference) de-references thePXReference
%   to its corresponding PXObject, unless the item
%   is already a PXObject.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 04-Apr-1997 14:09:46.

if nargin < 1, help(mfilename), return, end

result = thePXReference;

if ishandle(thePXReference)
   result = px(thePXReference);
end

if nargout > 0
   theObject = result;
  else
   disp(result)
end
