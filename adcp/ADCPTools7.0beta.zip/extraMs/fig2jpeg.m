function theOutputFile = fig2jpeg(theFilename, theFigure)

% fig2jpeg -- Save a figure in JPEG format.
%  fig2jpeg('theFilename', theFigure) saves theFigure
%   (default = current figure) to 'theFilename'.  If
%   no flename is given, the Matlab "uiputfile" dialog
%   is invoked.
 
% Copyright (C) 2000 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 03-Jan-2000 17:35:28.
% Updated    03-Jan-2000 17:35:28.

if nargout > 0, theOutputFile = []; end

if nargin < 1
	[f, p] = uiputfile('unnamed.jpg', 'Save Figure As JPEG:');
	if ~any(f)
		help(mfilename)
		return
	end
	if p(end) ~= filesep, p(end+1) = filesep; end
	theFilename = [p f];
end
if nargin < 2, theFigure = gcf; end

theOldFigure = gcf;

figure(theFigure)
[x, map] = getframe(theFigure);
imwrite(x, map, theFilename, 'jpg','quality',100)
%imwrite(x, map, theFilename, 'tiff')

if nargout > 0, theOutputFile = which(theFileName); end
