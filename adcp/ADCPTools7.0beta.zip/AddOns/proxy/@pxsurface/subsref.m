function theResult = subsref(self, theStruct)

% pxsurface/subsref -- Reference of x, y, z, c, and s data.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 18-Jun-1997 09:00:18.

if nargin < 2, help(mfilename), return, end

theType = theStruct(1).type;
theSubs = theStruct(1).subs;
if ~iscell(theSubs), theSubs = {theSubs}; end

inherit = 'result = subsref(super(self), theStruct);';

switch theType
case '.'
   switch theSubs{1}
   case {'x', 'y', 'z', 'c'}
      theTarget = [upper(theSubs{1}) 'Data'];
      result = pxget(self, theTarget);
      [m, n] = size(result);
      if length(theStruct) > 1
         switch theStruct(2).type
         case '()'
            switch length(theStruct(2).subs)
            case 1
               i = theStruct(2).subs{1};
               switch class(i)
               case 'char'
                  switch i
                  case ':'
                     result = result(:);
                  otherwise
                     eval(inherit)
                  end
               case 'double'
                  result = result(i);
               case 'pxsurface'
                  result = result(i);
               otherwise
                  eval(inherit)
               end
            case 2
               i = theStruct(2).subs{1};
               switch class(i)
               case 'char'
                  switch i
                  case ':'
                     i = 1:size(result, 1);
                  otherwise
                  end
               end
               j = theStruct(2).subs{2};
               switch class(j)
               case 'char'
                  switch j
                  case ':'
                     j = 1:size(result, 2);
                  otherwise
                     eval(inherit)
                  end
               otherwise
                  eval(inherit)
               end
               result = result(i, j);
            otherwise
               eval(inherit)
            end
         otherwise
            eval(inherit)
         end
      end
   case 's'
      result = pxvalue(self);
   otherwise
      eval(inherit)
   end
otherwise
   eval(inherit)
end

switch theSubs{1}
case 's'
   result = logical(result);
otherwise
end
   
if nargout > 0, theResult = result; end
