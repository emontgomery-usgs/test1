function self = PXLayout(theUI, theNormalizedPos, thePixelOffset)

% PXLayout -- Layout geometry for a "px" UI object.
%  PXLayout(theUI, theNormalizedPos, thePixelOffset) creates
%   a PXLayout object for the UI, a uicontrol.  The given geometry
%   refers to the normalized and pixel dimensions of the figure in
%   which the UI control is embedded.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 16-Apr-1997 14:08:44.

if nargin < 1, help(mfilename), setdef(mfilename), return, end

if nargin < 2, thePixelOffset = [0 0 0 0]; end

theStruct.itSelf = theUI;
self = class(theStruct, 'pxlayout', px(theUI));
pxset(self, 'itsObject', self)

h = px(self);
pxenable(h, h);
pxenable(h, 'Callback')

pxset(h, 'itsNormalizedPos', theNormalizedPos)
pxset(h, 'itsPixelOffset', thePixelOffset)
