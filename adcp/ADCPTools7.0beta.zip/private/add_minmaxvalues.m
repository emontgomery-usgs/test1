% ADD_MINMAXVALUES calculate min and max for variables in a netCDF file and
% add as an attribute.

function add_minmaxvalues(nc)
theVars = var(nc);
for i = 1:length(theVars),
    if ~strcmp(ncnames(theVars{i}),'time') && ...
            ~strcmp(ncnames(theVars{i}),'time2') && ...
            ~strcmp(ncnames(theVars{i}),'TIM'),
        data = theVars{i}(:);
        [row, col] = size(data);
        if col == 1,
            theVars{i}.minimum = ncfloat(gmin(data));
            theVars{i}.maximum = ncfloat(gmax(data));
        elseif col == 2,
            theVars{i}.minimum = ncfloat(gmin(gmin(data)));
            theVars{i}.maximum = ncfloat(gmax(gmax(data)));
        elseif col > 2, % then these are amp and cor or some other 3d var
            for icol = 1:col,
                mins(icol) = gmin(data(:,icol));
                maxs(icol) = gmax(data(:,icol));
            end
            theVars{i}.minimum = ncfloat(mins);
            theVars{i}.maximum = ncfloat(maxs);
        end
    end
end
return


