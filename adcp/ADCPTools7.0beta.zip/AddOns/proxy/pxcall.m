function varargout = PXCall(theFcn, varargin)

% PXCall -- Call a function with variable argument list.
%  {varargout} = PXCall('theFcn', {varargin}) performs
%   a call to 'theFcn' function, using the given input
%   and output arguments.  The varargin{1} must be a
%   reference to a "px" object.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 07-Apr-1997 13:50:38.

if nargin < 1, help(mfilename), return, end

if length(varargin) > 0
   varargin{1} = px(varargin{1});
end

varargout = cell(1, nargout);

theCall = vargstr(theFcn, length(varargin), length(varargout));

onFailure = ['## Error while trying: ' theCall];

eval(theCall, 'disp(onFailure)');   % Note two arguments.
