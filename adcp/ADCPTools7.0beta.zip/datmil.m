function [sdate,yyyy,mm,dd] = datmil(ndat)

%function[yyyymmdd] = datmil(ndat)
% ndat is a date number as given in the matlab datenum format
% and is turned into the military date format of yyyy/mm/dd
% Also gives the year, month, and day broken into pieces

%Jessica M. Cote, March 2000
%US Geological Survey
%Woods Hole, MA

[y,m,d] = datevec(floor(ndat));

yyyy = num2str(y);
if m < 10
   mm = ['0' num2str(m)];
else
   mm = num2str(m);
end

if d < 10
   dd = ['0' num2str(d)];
else
   dd =  num2str(d);
end

sdate = [yyyy '/' mm '/' dd];

