function status = DoZoomX(theFactor, theAxes)

% DoZoomX -- No help available.
% DoZoomX -- Zoom the limits of 'x' axes.
%  DoZoomX(theFactor, theAxes) zooms the 'x' limits of theAxes
%   (default = all axes in gcf) by theFactor (default = 2).
 
% Copyright (C) 1996-7 Dr. Charles R. Denham, ZYDECO.
% All Rights Reserved.

if nargin < 1, theFactor = 2; end
if nargin < 2, theAxes = []; end

result = dozoom(theFactor, theAxes, 'x');

if nargout > 0, status = result; end
