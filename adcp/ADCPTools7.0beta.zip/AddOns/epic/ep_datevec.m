function [y, m, d, h, mi, s] = EP_DateVec(theEpicTime)

% EP_DateVec -- Matlab fate-vector from epic-time.
%  EP_DateVec(theEpicTime) returns the Matlab date-vector
%   that corresponds to theEpicTime [time time2].  See
%   the Matlab "datevec()" function.
%  EP_DateVec('demo') demonstrates itself.
%  EP_DateVec (no argument) shows "help" and demonstrates itself.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 01-Jul-1997 15:54:18.

% Note: May 23, 1968 = Julian Day 2,440,000.

if nargin < 1, help(mfilename), theEpicTime = 'demo'; end

if strcmp(theEpicTime, 'demo')
   theEpicTime = ep_time('23-May-1968');
   if exist('begets')
      begets('EP_DateVec', 1, theEpicTime, ep_datevec(theEpicTime))
     else
      disp([' ## EP_DateVec(''' theEpicTime ''') ==> ' ep_datevec(theEpicTime)])
   end
   return
end

t = datevec(ep_datenum(theEpicTime));

switch nargout
case 1
   y = t;
case {3, 6}
   y = t(1); m = t(2); d = t(3); h = t(4); mi = t(5); s = t(6);
otherwise
   disp(t)
end
