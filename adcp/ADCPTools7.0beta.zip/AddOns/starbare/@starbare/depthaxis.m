function depthaxis(self)

% starbare/depthaxis -- Set depth-axis labels.
%  depthaxis(self) adjusts the labels ot the depth-axis
%   of self, a "starbare" object.
 
% Copyright (C) 1998 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 25-Sep-1998 11:46:32.

if nargin < 1, help(mfilename), return, end

theData = pxget(self, 'itsData');
theDepthName = pxget(self, 'itsDepthName');
theVariables = pxget(self, 'itsVariables');
theTransform = theData.transform(:);

% Get variable names.

len = length(theVariables);
for k = 1:len
	if ischar(theVariables{k})
		theVariables{k} = theData{theVariables{k}};
	end
	theVarNames{k} = name(theVariables{k});
end

% Change names if earth-coordinates.

if any(findstr(lower(theTransform), 'eart'))
	for k = 1:len
		switch theVarNames{k}
		case 'vel1'
			theVarNames{k} = 'East';
		case 'vel2'
			theVarNames{k} = 'North';
		case 'vel3'
			theVarNames{k} = 'Up';
		case 'vel4'
			theVarNames{k} = 'Error';
		end
	end
end

% Compute depth-axis.

if isequal(theDepthName, 'D')
	theDepth = theData{theDepthName};
	y = theDepth(:);
	y(y == -999999) = nan;
	if any(isnan(y))
		% Compute the depths from attributes.
		wd = theDepth.water_depth(:);
		xo = theDepth.xducer_offset_from_bottom(:);
		bc = theDepth.bin_count(:);
		bs = theDepth.bin_size(:);
		cf = theDepth.center_first_bin(:);
		dz = (0:bc-1) * bs + cf;
		ot = theData.orientation(:);
		up = isequal(lower(ot), 'up');
		if up
			y = wd - xo - dz;
		else
			y = wd - xo + dz;
		end
	end
	theYTick = get(gca, 'YTick');
	y = y(round(theYTick));
end

% Modify ticks and labels.

for k = 1:len
	subplot(len, 1, k)
	set(gca, 'YTickMode', 'auto', 'YTickLabelMode', 'auto')
	if isequal(theDepthName, 'D')
		if all(isfinite(y))
			for i = 1:length(y)
				theYTickLabel{i} = num2str(round(y(i)));
			end
			if length(y) > 6
				for i = length(y):-2:1
					theYTickLabel{i} = '';
				end
			end
			set(gca, 'YTick', theYTick, 'YTickLabel', theYTickLabel)
			theUnits = theData{theDepthName}.units(:);
			theYLabel = [theVarNames{k} ' (depth'];
			if any(theUnits)
				theYLabel = [theYLabel ' ' theUnits];
			end
			theYLabel = [theYLabel ')'];
		end
	else
		theYLabel = [theVarNames{k} ' (bin #)'];
	end
	ylabel(theYLabel)
end
