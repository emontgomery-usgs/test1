function theResult = PXUI(self)

% PXUI -- UI of a "px" object.
%  PXUI(self) returns the handle of the UI
%   attached to self, a "px" object.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 08-Apr-1997 10:16:50.

if nargin < 1, help(mfilename), return, end

result = self.itsUI;

if nargout > 0
   theResult = result;
  else
   disp(result)
end
