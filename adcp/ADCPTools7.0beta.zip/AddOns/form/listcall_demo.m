function theResult = listcall_demo(nItems)

% listcall_demo -- Demonstration of "ListCall".
%  listcall_demo (no argument) demonstrates
%   a 'listcall" modal dialog.  The code given
%   here shows how to capture and update the
%   contents of the "listcall" dialog box.
%   In this example, a three-state system is
%   toggled, using the letter 'X' to show the
%   current state of each item in the list.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 13-Jan-1998 20:11:58.

mode = ~isempty(gcbo);

theMark = setstr(165);   % Bullet.
if ~any(findstr(computer, 'MAC'))
    theMark = 'X';
end

switch mode
case 0   % Setup the "listcall" dialog.
    if nargin < 1, nItems = 50; end
    theStrings = cell(nItems, 1);
    for i = 1:length(theStrings);
        s = [theMark ' - - ' int2str(i)];
        theStrings{i} = s;
    end
    theCall = 'listcall_demo';
    thePrompt = 'Toggle';
    theName = 'ListCall Demo';
    a = listcall(theStrings, thePrompt, theName, theCall);
    if nargout > 0
        theResult = a;
    else
        assignin('caller', 'ans', a);
    end
otherwise   % Process the "listcall" picks.
    theGCBO = gcbo;
    theStrings = get(theGCBO, 'String');
    theValue = get(theGCBO, 'Value');
    s = theStrings{theValue};
    code = s(1:5);
    f = find(code == theMark);
    if ~any(f), f = 0; end
    switch f
    case 1
        code = ['- ' theMark ' -'];
    case 3
        code = ['- - ' theMark];
    case 5
        code = [theMark ' - -'];
    otherwise
    end
    s(1:5) = code;
    theStrings{theValue} = s;
    set(theGCBO, 'String', theStrings)
    set(theGCBO, 'Value', theValue)
end
