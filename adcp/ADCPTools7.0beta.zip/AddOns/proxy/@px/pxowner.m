function theResult = PXOwner(self)

% PXOwner -- Owner of a "px" object.
%  PXOwner(self) returns the 'itsOwner'
%   field of self, a "px" object.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 08-Apr-1997 10:16:50.

if nargin < 1, help(mfilename), return, end

result = doget(self, 'itsOwner');

if nargout > 0
   theResult = result;
  else
   disp(result)
end
