function PXHome(theFigure)

% PXHome -- Restore a figure to its "Home" view.
%  PXHome(theFigure) restores theFigure to its "Home"
%   view.  TheFigure defaults to the current figure.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 08-Apr-1997 16:34:57.

% Find the axes and sliders.

if nargin < 1, theFigure = gcf; end

theAxes = findobj(theFigure, 'Type', 'axes');

theSliders = findobj(theFigure, 'Type', 'uicontrol', ...
                                'Style', 'slider');

% Home -- Unzoomed view and centered scrollbars.

theCurrentAxes = gca;
for i = 1:length(theAxes)
   axes(theAxes(i)), view(2)
   set(theAxes(i), 'CLimMode', 'auto')
   axis('tight')
end
axes(theCurrentAxes)

for i = 1:length(theSliders)
   theMin = get(theSliders(i), 'Min');
   theMax = get(theSliders(i), 'Max');
   lims = [theMin theMax];
   theValue = (max(lims) + min(lims)) ./ 2;
   set(theSliders(i), 'Value', theValue)
end

pxscroll

if nargout > 0, status = 0; end
