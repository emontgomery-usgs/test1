function theResult = PXResize(self)

% PXWindow/PXResize -- Resize layouts in a "pxwindow" object.
%  PXResize(self) resizes the layouts associated
%   with self, a "pxwindow" object.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 09-Apr-1997 15:33:56.

theFigure = px(self);

f = findobj(theFigure, 'Type', 'uicontrol');
for i = 1:length(f)
   theObject = px(f(i));
   if isa(theObject, 'pxlayout')
      pxresize(theObject)
   end
end
