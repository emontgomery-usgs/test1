function Proxy

% Proxy - No help available.
% Proxy -- Switch to the "proxy" directory.
%  Proxy (no argument) switches to the "proxy" directory.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 07-Apr-1997 06:38:52.

setdef(mfilename)
