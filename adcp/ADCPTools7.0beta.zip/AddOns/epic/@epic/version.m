function version(self)

% Version of 08-Nov-1999 09:44:25.

helpdlg(help(mfilename), 'epic')
