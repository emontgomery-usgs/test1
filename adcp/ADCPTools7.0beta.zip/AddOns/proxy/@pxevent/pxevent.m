function theResult = PXEvent(theUI, thePXEvent, theMessage)

% PXEvent -- No help available.
% PXEvent -- Dispatch an action.
%  PXEvent(theUI, thePXEvent, theMessage) dispatches
%   thePXEvent and theMessage to the 'pxevent' method
%   of the PXOwner of theUI.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 12-Jun-1997 08:24:14.

if nargin < 1, help(mfilename), return, end

if theUI == 0, return, end
if nargin < 2, theEvent = ''; end
if nargin < 3, theMessage = []; end

if 0
   pxbegets(' ## PXEvent', 3, theUI, thePXEvent, theMessage)
end

% The originator.

theType = get(theUI, 'Type');

% Default action.

if isempty(thePXEvent)
   thePXEvent = get(theUI, 'Tag');
   if isempty(thePXEvent)
      if strcmp(theType, 'uimenu')
         theString = get(theUI, 'Label');
        elseif strcmp(theType, 'uicontrol')
         theStyle = get(theUI, 'Style');
         theString = get(theUI, 'String');
         if strcmp(theStyle, 'popupmenu') | ...
            strcmp(theStyle, 'listbox')
            theValue = get(theUI, 'Value');
            theString = theString(theValue, :);
         end
         thePXEvent = theString;
      end
   end
end

% Default message.

if isempty(theMessage), theMessage = theUI; end

% De-reference uimenu or uicontrol to the parent figure.

if strcmp(theType, 'uimenu') | ...
   strcmp(theType, 'uicontrol')
   while ~strcmp(theType, 'figure')
      theUI = get(theUI, 'Parent');
      theType = get(theUI, 'Type');
   end
end

% Dispatch the event.

thePXOwner = pxowner(theUI);

result = pxevent(px(thePXOwner), thePXEvent, theMessage);

if nargout > 0, theResult = result; end
