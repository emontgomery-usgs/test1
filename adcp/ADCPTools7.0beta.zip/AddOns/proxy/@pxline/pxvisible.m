function theResult = PXVisible(self, theVisible)

% PXLine/PXVisible -- Show or hide.
%  PXVisible(self, 'theVisible') shows or hides self, a "pxline"
%   object, according to 'theVisible' ('on' [default] or 'off'),
%   which may be input optionally as 1 or 0.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 30-Jul-1997 09:24:26.

if nargin < 1, help(mfilename), return, end
if nargin < 2, theVisible = 'on'; end

if ~isstr(theVisible)
   switch theVisible
   case 0
      theVisible = 'off';
   otherwise
      theVisible = 'on';
   end
end

h = [pxget(self, 'itsMask') px(self)];
set(h, 'Visible', theVisible)

if nargout > 0, theResult = self; end
