function theResult = PXGet(self, theField)

% PXGet -- No help available.
% PXGet -- Get field value of self, a "px" object.
%  PXGet(self, theField) returns the value of
%   theField of self, as in the notation
%   "theValue = self.theField".
%  PXGet(self) returns all the fields of self
%   as a "struct" object.
%  PXGet (no argument) shows help.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 04-Apr-1997 14:42:24.

if nargin < 1, help(mfilename), return, end

switch nargin
case 1
   result = pxset(self);
case 2
   result = pxset(self, theField);
otherwise
   result = [];
end

switch nargout
case 0
   disp(result)
otherwise
   theResult = result;
end
