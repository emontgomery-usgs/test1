function theResult = display(self)

disp(' ')
disp([inputname(1) ' ='])
disp(' ')
disp(self)
