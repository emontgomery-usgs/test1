function theResult = PXGet(self, theField)

% PXGet -- No help available.
% PXGet -- Get field value of self, a px reference.
%  PXGet(self, theField) returns the value of
%   theField of self, a "px" reference.
%  PXGet(self) returns all the fields of self
%   as a "struct" object.
%  PXGet (no argument) shows help.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 04-Apr-1997 13:31:58.

if nargin < 1, help(mfilename), return, end

result = [];

switch nargin
case 0
   help(mfilename), return
case 1
   result = pxget(px(self));
otherwise
   result = pxget(px(self), theField);
end

if nargout > 0
   theResult = result;
  else
   disp(result)
end
