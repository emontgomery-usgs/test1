function theResult = changed(self, newFlag)

% pximage/changed -- Get/set "change" flag.
%  changed(self) returns the "change" flag of self,
%   a "pximage" object, either 0 or 1.
%  changed(self, newFlag) sets the "changed" flag
%   of self to the newFlag, either 0 or 1.
 
% Copyright (C) 1999 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 12-Jan-1999 18:06:37.

if nargin < 1, help(mfilename), return, end

if nargin < 2
	result = pxget(self, 'itHasChanged');
else
	result = self;
	pxset(result, 'itHasChanged', newFlag);
end

if nargout > 0
	theResult = result;
else
	disp(result)
end
