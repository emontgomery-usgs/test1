function theResult = Event(self)

% ListCall/Event -- Event handler.
%  Event(self) handles mouse events associated
%   with self, a "listcall" object.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 13-Jan-1998 17:58:49.

if nargin < 1, help(mfilename), return, end
if nargin < 2, theMode = 'normal'; end

theFigure = self.itSelf;

theList = findobj(theFigure, 'Tag', 'List');
theOkay = findobj(theFigure, 'Tag', 'Okay');
theCancel = findobj(theFigure, 'Tag', 'Cancel');

theTag = get(gcbo, 'Tag');
theValue = get(gcbo, 'Value');

switch lower(theTag)
case 'list'
    theCall = get(gcbo, 'Userdata');
    if ~isempty(theCall)
        eval(theCall);
    else
        theStrings = get(theList, 'String');
        disp([' ## ' theStrings{theValue}])
    end
case {'cancel', 'okay'}
    theStrings = get(theList, 'String');
    set(theOkay, 'UserData', theStrings)
    set(theCancel, 'UserData', [])
    set(theFigure, 'UserData', [])   % Ends "modal" state.
otherwise
end
