function theResult = PXValue(self, theValue)

% PXValue -- Set/get the value.
%  PXValue(self, theCallback) sets the current
%   value of self, a "px" object, to theValue.
%  PXValue(self) returns the value of self.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 06-Jun-1997 10:40:13.

if nargin < 1, help(mfilename), return, end

if nargin < 2
   result = pxget(self, 'itsValue');
  else
   result = pxset(self, 'itsValue', theValue);
end

if nargout > 0, theResult = result; end
