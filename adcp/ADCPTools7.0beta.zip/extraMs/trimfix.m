function trimfix(infile,outfile,rec1,rec2)

% function trimfix(infile,outfile,rec1,rec2)
% Uses the Record number given in rec1 and rec2 to 
% locate the correct indices and then submits the file to nctrim 
% retaining only the records between rec1 and rec2.
%
% If rec1 is not given the first record number will be used.
% Likewise if rec2 is not given, the last record number will be used.
% To trim ensembles at the end of the data set,
% specify only rec2 and default to the first record for rec1, 
% set rec1 = ' ', and give an ensemble number for rec2.
% example: trimfix('564whT.cdf','564whTt.cdf',' ',5678)	
%
% Written by Jessica M. Cote
% for the U.S. Geological Survey
% Coastal and Marine Geology Program
% Woods Hole, MA
% http://woodshole.er.usgs.gov/
% Please report bugs to jcote@usgs.gov

h = netcdf(infile,'nowrite')
if isempty(h),return, end

ftime = h{'TIM'};
jtime = ftime(:);

rec = h{'Rec'}(:);
first = rec(1);
last = rec(end);

if nargin < 3 | isempty(rec1), rec1 = first;, end
if nargin < 4, rec2 = last;, end

%if rec2 given is greater than the last ensembel number you get garbage
if rec2 > last
   error('rec2 is too big')
end

if first > 1
   if rec1 > 2
      beg = rec1-first+1;
   else
      beg = rec1;
   end
   
   Rend = rec2 - first;  
else
   beg = rec1;
   Rend = rec2;
end

ncclose(h)
disp(['trim ' infile ' from index ' num2str(beg) ' to ' num2str(Rend) ';'])

nctrim(infile,outfile,(beg:Rend));

thecomment='additional ensembles were trimmed by trimfix.m';
history(outfile,thecomment);

ncclose