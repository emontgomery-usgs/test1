function theResult = disp(self)

disp(data(self))
