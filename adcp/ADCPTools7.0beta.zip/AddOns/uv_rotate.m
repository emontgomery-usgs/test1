function [ur,vr] = uv_rotate(u,v,theta)

%  uv_rotate:  rotates (east, north) current components
%
% function [ur,vr] = uv_rotate(u,v,theta)
%      (u,v) are (east, north) current components.
%      theta is rotation angle in compass degrees.
%      ur is the current component in a direction 
%          theta degrees clockwise from east.
%      vr is the current component in a direction 
%          theta degrees clockwise from north.

[dir,spd] = uv2polar(u,v);
dir = dir - theta;
[ur,vr] = polar2uv(dir,spd);
