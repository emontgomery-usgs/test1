function theResult = PXUI(self)

% PXUI -- UI owned by a "px" reference.
%  PXUI(self) returns the 'itsUI'
%   field from the object represented
%   by self, a PXReference.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 08-Apr-1997 10:12:01.

if nargin < 1, help(mfilename), return, end

theObject = pxderef(self);
result = theObject.itsUI;

if nargin > 0
   theResult = result;
  else
   disp(result)
end
