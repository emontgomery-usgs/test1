function fixval(filename, threshold)  

if nargin < 2, threshold=1e30;, end

h = netcdf(filename,'write')
if isempty(h),return, end

names={'vel1','vel2','vel3','vel4','cor1','cor2','cor3','cor4',...
      'AGC1','AGC2','AGC3','AGC4','PGd1','PGd2','PGd3','PGd4',...
      'Hdg','Ptch','Roll','Tx'};

for i=1:length(names)
   disp(names{i})
   v = h{names{i}};
   data = v(:);
   fill = fillval(v)
   
   k = find(abs(data) > threshold);
   disp(int2str(length(k)))
   data(k) = fill;
   v(:) = data;
end

close(h)