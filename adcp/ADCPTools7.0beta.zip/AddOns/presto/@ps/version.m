function version(self)

% Version of 16-Dec-1999 12:07:28.

helpdlg(help(mfilename), 'ps')
