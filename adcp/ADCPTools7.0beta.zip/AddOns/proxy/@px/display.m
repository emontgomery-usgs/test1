function display(self)

% disp -- Display a "px" object.
%  disp(self) displays the fields of self,
%   a "px" object.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 07-Apr-1997 08:32:37.

if nargin < 1, help(mfilename), return, end

disp(' ')
disp([inputname(1) ' ='])
disp(self)
