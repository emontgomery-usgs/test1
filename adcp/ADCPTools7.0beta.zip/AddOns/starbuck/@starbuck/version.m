function version(self)

% Version of 21-Dec-1999 13:48:25.

helpdlg(help(mfilename), 'starbuck')
