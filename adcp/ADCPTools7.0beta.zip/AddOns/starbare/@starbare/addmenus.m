function theResult = AddMenus(self)

% StarBare/AddMenus -- Add menus to "starbare" window.
%  AddMenus(self) adds menus to the window associated
%   with self, a "starbear" object.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 21-Jul-1997 16:30:13.
% Updated    07-Jul-1999 10:09:10.

if nargin < 1, help(mfilename), return, end

set(gcf, 'MenuBar', 'figure')

h = findobj(gcf, 'Type', 'uimenu');
if any(h), delete(h), end

% New menus.

theVarnames = [ ...
{'-Beam';
'>>Beam 1';
'>>Beam 2';
'>>Beam 3';
'>>Beam 4';
'-Beams';
'>>Velocity';
'>>Horizontal Velocity';
'>>Vertical Velocity';
'->Correlation';
'>>Intensity';
'>>Percent Good';
'-Instrument';
'>>Tilt';
'->Voltage';
};
];

theLabels = [ ...
{'<StarBare>'; ...
'>About StarBare...';
'-Setup...';
'-Graph'; ...
'>>Line'; ...
'>>Circles'; ...
'>>Dots'; ...
'->Contour'; ...
'>>Image'; ...
'->Progressive Vector'; ...
'>>Scatter Plot'; ...
'->Wiggles X'; ...
'>>Wiggles Y'; ...
'->Averaging On';
'>>Averaging Off';
'->Colorbars On'; ...
'>>Colorbars Off'; ...
'->Page Setup...'; ...
'>>Print'; ...
'->Update'; ...
'-Time Axis'; ...
'>>Time'; ...
'->Record'; ...
'-Depth Axis'; ...
'>>Depth'; ...
'->Bin'; ...
}; ...
theVarnames;  ...
{
'-Done'; ...
}
];

s = setstr([abs('a'):abs('z') abs('0123456789')]);

theMenus = [];
theCalls = cell(size(theLabels));
theTags = cell(size(theLabels));
for i = 1:length(theLabels)
   theCalls{i} = 'pxevent';
   theTag = lower(theLabels{i});
   for j = length(theTag):-1:1
      if ~any(theTag(j) == s)
         theTag(j) = '';
      end
   end
   theTags{i} = theTag;
end
		
theMenus = [theMenus; pxmenu(gcf, theLabels)];

if nargout > 0, theResult = theMenus; end
