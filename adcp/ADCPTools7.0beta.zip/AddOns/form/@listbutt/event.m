function theResult = Event(self)

% ListButt/Event -- Event handler.
%  Event(self) handles mouse events associated
%   with self, a "listbutt" object.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 13-Jan-1998 17:58:49.

if nargin < 1, help(mfilename), return, end
if nargin < 2, theMode = 'normal'; end

theFigure = self.itSelf;

theList = findobj(theFigure, 'Tag', 'List');

theTag = get(gcbo, 'Tag');
theValue = get(gcbo, 'Value');
theButtons = get(theList, 'String');
theButton = theButtons{theValue};

if all(theButton == ' ')
    switch get(gcf, 'resize')
    case 'off'
        set(gcf, 'Resize', 'on')
    otherwise
        set(gcf, 'Resize', 'off')
    end
    return
end

switch lower(theTag)
case 'list'
    theCallbacks = get(gcbo, 'Userdata');
    if length(theCallbacks) > 1 & ...
            length(theCallbacks) >= theValue
        theCall = theCall{theValue};
    else
        theCall = theCallbacks{1};
    end
    if ~isempty(theCall)
        feval(theCall, theButton);
    else
        theStrings = get(theList, 'String');
        disp([' ## ' theButton])
    end
otherwise
end
