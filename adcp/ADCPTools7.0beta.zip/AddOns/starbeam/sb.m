function StarBeam

% StarBeam -- Switch to the "starbeam" directory.
 
% Copyright (C) 1998 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 14-Sep-1998 14:37:19.

setdef(mfilename)
