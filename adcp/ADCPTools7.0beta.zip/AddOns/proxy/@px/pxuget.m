function theResult = PXUGet(self)

% PXUGet -- Get the UserData associated with self.
%  PXUGet(self) returns the 'UserData' associated with
%   self, a "px" object.
%  PXUGet (no argument) shows help.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 04-Apr-1997 14:37:01.

switch nargin
case 0
   help(mfilename), return
otherwise
   result = self(:);
end

switch nargout
case 0
   disp(result)
otherwise
   theResult = result;
end
