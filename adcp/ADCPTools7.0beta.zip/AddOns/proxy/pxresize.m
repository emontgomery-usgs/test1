function PXResize(theFigure)

% PXResize -- Resize "pxlayout" objects.
%  PXResize(theFigure) resizes the "pxlayout" items in
%   theFigure by calling their own "pxresize" methods.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 09-Apr-1997 16:01:26.

% Force a 'ResizeFcn' event in theFigure.

if nargin < 1, theFigure = gcf; end

if strcmp(get(theFigure, 'Type'), 'figure')
   theVisible = get(theFigure, 'Visible');
   set(theFigure, 'Visible', 'off')
   pos = get(theFigure, 'Position');
   set(theFigure, 'Position', pos .* 0.5);
   set(theFigure, 'Position', pos, 'Visible', theVisible);
end
