function theResult = PXEvent(self, theEvent, theMessage)

% PXEvent -- Process events for a "pxwindow" object.
%  PXEvent(self, theEvent, theMessage) processes
%   events associated with self, a "pxwindow" object.
%   The returned status is non-zero if theEvent was
%   not handled.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 16-Apr-1997 09:23:16.

if nargin < 1, help(mfilename), return, end
if nargin < 2, theEvent = ''; end
if nargin < 3, theMessage = []; end

if pxverbose
   pxbegets(' ## PXEvent', 3, self, theAction, theMessage)
end

status = 0;

switch lower(theEvent)
case 'resizefcn'
   pxresize(self)
otherwise   % Inherit.
   status = pxevent(super(self), theEvent, theMessage);
end

if nargout > 0, theResult = status; end
