function theResult = Counts(self, theBins, theChunkSize)

% Counts -- Update histogram counts.
%  Counts(self, theBins, theChunkSize) updates self,
%   a "pxhist" object, with the new parameters.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 29-Jul-1997 14:58:12.

theXData = pxget(self, 'itsXData');
theYData = pxget(self, 'itsYData');
theOldBins = pxget(self, 'itsBins');
theOldChunkSize = pxget(self, 'itsChunkSize');

if nargin < 2, theBins = 10; end
if nargin < 3, theChunkSize = fix((length(theXData) + 19) ./ 20); end

pxdelete(self)

self = pxhist(theXData, theYData, theBins, theChunkSize);

if nargout > 0, theResult = self; end
