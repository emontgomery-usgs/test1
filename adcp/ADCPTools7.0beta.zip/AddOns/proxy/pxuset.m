function theResult = PXUSet(self, theUserData)

% PXUSet -- Get the UserData of a "px" object.
%  PXUSet(self, theUserData) sets the 'UserData'
%   of self, a "px" reference, to theUserData.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 08-Apr-1997 09:22:04.

if nargin < 1, help(mfilename), return, end

if nargin > 1
   set(self, 'UserData', theUserdata);
end

result = get(self, 'UserData');

if nargin < 2
   if nargout > 0
      theResult = result;
     else
      disp(result)
   end
end
