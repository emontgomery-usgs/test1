function theResult = PXSet(self, theField, theValue)

% PXSet -- No help available.
% PXSet -- Set values in self, a px reference.
%  PXSet(self, 'theField', theValue) sets
%   'theField' of self, a "px" reference,
%   to theValue.
%  PXSet(self, 'theField') returns the value
%   of 'theField' of self.
%  PXSet(self) returns all the fields of self
%   as a "struct" object.
%  PXSet (no argument) shows help.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 04-Apr-1997 13:31:58.

if nargin < 1, help(mfilename), return, end

result = [];

switch nargin
case 0
   help(mfilename), return
case 1
   result = pxset(px(self));
   if nargout < 1, disp(result), end
case 2
   result = pxset(px(self), theField);
otherwise
   result = pxset(px(self), theField, theValue);
end

if nargout > 0
   theResult = result;
  elseif nargin < 3
   disp(result)
end
