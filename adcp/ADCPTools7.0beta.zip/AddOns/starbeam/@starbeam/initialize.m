function theResult = initialize(self)

% starbeam/initialize -- Initialize "StarBeam".
%  initialize(self) initializes self, a "starbeam" object,
%   then calls "starbeam/update'.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 03-Apr-1998 14:19:26.
% Updated    05-Oct-1999 13:10:41.

if nargin < 1, help(mfilename), return, end

theData = pxget(self, 'itsData');

theTimeName = pxget(self, 'itsTimeName');
theTimeUnits = pxget(self, 'itsTimeUnits');
theDepthName = pxget(self, 'itsDepthName');
theDepthUnits = pxget(self, 'itsDepthUnits');

ensemble = theData('ensemble');
bin = theData('bin');

theEnsembleMax = prod(size(ensemble));
theBinMax = prod(size(bin));

pxset(self, 'itIsEnsembleAveraging', 0);
pxset(self, 'itsEnsembleStart', 1);
pxset(self, 'itsEnsembleStop', min(theEnsembleMax, 50));
pxset(self, 'itsEnsembleCount', min(theEnsembleMax, 50));
pxset(self, 'itsEnsembleStep', 1);
pxset(self, 'itsEnsembleMax', theEnsembleMax);

pxset(self, 'itsBinStart', 1);
pxset(self, 'itsBinStop', theBinMax);
pxset(self, 'itsBinCount', theBinMax);
pxset(self, 'itsBinStep', 1);
pxset(self, 'itsBinMax', theBinMax);

pxset(self, 'itsPlotStyle', 'image')
pxset(self, 'itsLineStyle', '-')
pxset(self, 'itsMarker', 'none')
pxset(self, 'itsColor', [1 0 1])

pxset(self, 'itsColorBars', 'on')   % 'off' or 'on'.

pxset(self, 'itsRotationAngle', 0)

pxset(self, 'itsColorFactor', 1)   % For vertical velocity.

setup(self)

% Adjust the scrollbars.
	
s{1} = px(findobj(gcf, 'Style', 'slider', 'Tag', 'XScroll'));
s{2} = px(findobj(gcf, 'Style', 'slider', 'Tag', 'YScroll'));
theMax(1) = theEnsembleMax;
theMax(2) = theBinMax;
theSliderStep(1, :) = [50 1000] ./ theMax(1);
theSliderStep(2, :) = [1 10] ./ theMax(2);
for i = 1:2
	s{i}.Max = theMax(i);
	s{i}.Value = theMax(i);
	s{i}.Min = 1;
	s{i}.Value = 1;
	s{i}.SliderStep = theSliderStep(i, :);
end

switch theTimeName
case 'time'
	theVariables = {'u_1205', 'v_1206', 'w_1204', 'Werr_1201'};
otherwise
	theVariables = {'vel1', 'vel2', 'vel3', 'vel4'};
end

pxset(self, 'itsVariables', {theVariables});   % Note {}.

update(self)

if nargout > 0, theResult = self; end
