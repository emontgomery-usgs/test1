function ep

% ep -- Switch to the master epic directory.
%  ep (no arguments) switches to the directory
%   that contains the epic classes.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.

setdef(mfilename)
