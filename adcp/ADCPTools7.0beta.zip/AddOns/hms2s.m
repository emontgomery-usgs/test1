function [seconds]=hms2s(h,m,s);
%HMS2H converts hours, minutes, and seconds to seconds
%
%  Usage:  [seconds]=hms2s(h,m,s);   or [seconds]=hms2s(hhmmss);
%
if nargin < 2,
   hms=h;
   h=floor(hms/10000);
   ms=hms-h*10000;
   m=floor(ms/100);
   s=ms-m*100;
   seconds=h*3600+(m*60)+s;
else
   seconds=h*3600+(m*60)+s;
end
