function doabout(self)

% StarBuck is a browser for ADCP measurements stored in
%  NetCDF/EPIC files.
 
% Copyright (C) 1999 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 14-Dec-1999 13:44:12.
% Updated    14-Dec-1999 13:44:12.

helpdlg(help(mfilename), 'About StarBuck')
