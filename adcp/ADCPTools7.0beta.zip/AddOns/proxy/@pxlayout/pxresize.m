function theResult = PXResize(self)

% PXLayout/PXResize -- Resize a "pxlayout" graphical entity.
%  PXResize(self) resizes the graphic associated with
%   self, a "pxlayout" object.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 09-Apr-1997 15:33:56.

theUI = px(self);

theNormalizedPos = pxget(self, 'itsNormalizedPos');
thePixelOffset = pxget(self, 'itsPixelOffset');

if ~all(size(theNormalizedPos) == [1 4]) | ...
   ~all(size(theNormalizedPos) == [1 4])
   return
end

theFigure = get(self.itSelf, 'Parent');

oldUnits = get(theFigure, 'Units');
set(theFigure, 'Units', 'pixels')
theFigurePos = get(theFigure, 'Position');
set(theFigure, 'Units', oldUnits)

theUIPos = theFigurePos([3:4 3:4]) .* theNormalizedPos + thePixelOffset;

oldUnits = get(theUI, 'Units');
set(theUI, 'Units', 'pixels')
set(theUI, 'Position', theUIPos)
set(theUI, 'Units', oldUnits)
