function PXDemo

% PXDemo -- Demonstration of basic PX behaviors.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 04-Apr-1997 14:09:46.

setdef(mfilename)

help(mfilename)

theContainer = findobj('Type', 'figure', 'Name', 'PXDemo');

if isempty(theContainer)
   figure('Name', 'PXDemo', ...
      'Position', [16 48 128 32], ...
      'NumberTitle', 'off', ...
      'MenuBar', 'none');
   set(gca, 'Visible', 'off')
end

if (1)

disp(' ')
disp(' ## PXDemo')

disp(' ')
disp(' ## Base Class:')
disp(' ')
a = pxnew(px);   % A reference to a "px" object.
disp(px(a))    % "px" used for dereferencing.

disp(' ')
disp(' ## Subclass and Hello:')
disp(' ')
b = pxnew(qx);
bb = px(b); bb.itsGreeting = 'Hello World!';
disp(px(b))

disp(' ')
disp(' ## Clone and Goodbye:')
disp(' ')
c = px(b, []);
cc = px(c); cc.itsGreeting = 'Goodbye World!';
disp(px(c))

delete([a b c])

end

if isempty(theContainer), delete(gcf), end

nofigs

if (0)

a = pxnew(px(figure('Name', 'PXDemo -- Please Click In The Window', ...
                  'Visible', 'off', 'NumberTitle', 'off')));

pxenable(a, a)

pxenable(a, 'WindowButtonDownFcn')
pxenable(a, 'WindowButtonUpFcn')
pxenable(a, 'ResizeFcn')

end

a = pxnew(pxwindow('PXDemo -- Please Click In The Window', 'YX'));

symbol = '^v<>';
for i = 1:4
   subplot(2, 2, i)
   x = 0:10*i; y = x;
   plot(x, y, [symbol(i)])
end

if (0)

x = new(pxscrollbar('XScroll'));
pxenable(x, x);
y = new(pxscrollbar('YScroll'));
pxenable(y, y);

end

pxresize(a)

set(a, 'Visible', 'on')
