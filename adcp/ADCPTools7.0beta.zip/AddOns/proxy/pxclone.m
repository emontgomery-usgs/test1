function theResult = PXClone(theSrcReference, theDstHandle)

% PXClone -- Clone a "px" handle.
%  PXClone(theSrcReference, theDstHandle) clones the contents
%   of theSrcReference onto theDstHandle.  The destination
%   defaults to a new "px" reference.  The source contents
%   are left intact.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 04-Apr-1997 14:09:46.

if nargin < 1, help(mfilename), return, end
if nargin < 2, theDstHandle = []; end

if ispx(theSrcReference) == 1
   theSrcReference = px(theSrcReference);
end

result = px(px(px(theSrcReference), theDstHandle));

if nargout > 0
   theResult = result;
  else
   disp(result)
end
