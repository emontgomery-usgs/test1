function theResult = addmenus(self)

% starbuck/addmenus -- Add menus to "starbuck" window.
%  addmenus(self) adds menus to the window associated
%   with self, a "starbuck" object.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 21-Jul-1997 16:30:13.
% Updated    21-Dec-1999 09:34:44.

if nargin < 1, help(mfilename), return, end

set(gcf, 'MenuBar', 'figure')

h = findobj(gcf, 'Type', 'uimenu');
if any(h), delete(h), end

h = findobj(gcf, 'Type', 'uicontrol');
if any(h), delete(h), end

% New menus.

theMenuLabels = {
	'<StarBuck>'
		'>About...'
		'>Setup...'
		'-Velocity'
			'>>U-V'
			'>>U-V-W'
			'>>U-V-W-Err'
			'>>U-V-Err'
			'>>W-Err'
		'-Quality'
		'-Graph'
			'>>Line'
			'>>Circles'
			'>>Dots'
			'->Contour'
			'>>Image'
			'->Progressive Vector'
			'>>Scatter Plot'
			'->Wiggles X'
			'>>Wiggles Y'
			'->Averaging On'
			'>>Averaging Off'
			'->Colorbars On'
			'>>Colorbars Off'
			'->Page Setup...'
			'>>Print'
			'->Update'
		'-Time Axis'
			'>>Time'
			'->Ensemble'
		'>Depth Axis'
			'>>Depth'
			'->Bin'
		'-Done'
};

[self, theMenuHandles] = menu(self, theMenuLabels);

% New controls.

theControls(1) = control(self, 'bottom');
theControls(2) = control(self, 'right');

% Event-handlers.
%
%  Note: these are not being used presently; instead,
%   everything is being passed to "starbuck/doevent".

theEventHandlers = {
	'about', 'doabout', ...
	'update', 'doupdate', ...
	'setup', 'dosetup', ...
	'uv', 'dovelocity', ...
	'uvw', 'dovelocity', ...
	'uvwerr', 'dovelocity', ...
	'uverr', 'dovelocity', ...
	'werr', 'dovelocity', ...
	'quality', 'doquality', ...
	'time', 'dotimeaxis', ...
	'ensemble', 'dotimeaxis', ...
	'depth', 'dodepthaxis', ...
	'bin', 'dodepthaxis', ...
	'done', 'doquit', ...
	'resizefcn', 'doresize', ...
	'closerequestfcn', 'doquit', ...
	'bottom', 'doscroll', ...
	'right', 'doscroll', ...
};

self = handler(self, theEventHandlers{:});

enable(self)

if nargout > 0, theResult = self; end
