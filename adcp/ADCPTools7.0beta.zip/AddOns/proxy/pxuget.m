function theResult = PXUGet(self)

% PXUGet -- Get the UserData of a "px" object.
%  PXUGet(self) returns the 'UserData' of self,
%   a "px" reference.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 08-Apr-1997 09:22:04.

if nargin < 1, help(mfilename), return, end

result = pxuset(self);

if nargout > 0
   theResult = result;
  else
   disp(result)
end
