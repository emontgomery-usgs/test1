function xnew=gstd(x)
% gstd - just like std, except that it skips over NaN's, Inf's, etc.
%  Usage:  xnew=gstd(x);
%             x can be a vector or matrix
[imax,jmax]=size(x);
if(imax==1),
  imax=jmax;
  jmax=1;
  x=x.';
end
for j=1:jmax
       good=find(finite(x(:,j)));
       if length(good)>0
          xnew(j)=std(x(good,j));
       else
          xnew(j)=NaN;
       end
end
