function scr_vis(theFigure,vis)

%turns scroll bar on and off for printing
% theFigure = the figure handle such as figure(1);
% vis = 'on' or 'off'
% with vis = 'off', also get a white background

f = findobj(theFigure,'type','uicontrol');

if isequal(vis,'off')
	set(f,'visible','off')
   set(theFigure,'color',[1.0 1.0 1.0])
   
elseif isequal(vis,'on')
   set(f,'visible','on')
end
