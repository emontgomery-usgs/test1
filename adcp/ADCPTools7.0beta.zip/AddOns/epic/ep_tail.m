function theResult = EP_Tail(theSource, theDestination, theCount, theStride)

% EP_Tail -- Last part of an EPIC file.
%  EP_Tail('theSource', 'theDestination', theCount, theStride) places
%   the given range of data from the tail of 'theSource' file into
%   'theDestination' file.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 13-May-1997 14:36:03.

result = [];
if nargout > 0, theResult = result; end

if nargin < 2, help(mfilename), return, end

if nargin < 4, theStride = 1; end

dst = epic(theDestination, 'nowrite');
if isempty(dst), return, end
theSize = size(dst('time'));
close(dst)

theIndices = theSize:-theStride:1;
if theCount == -1, theCount = length(theIndices); end
if length(theIndices) > theCount
   theIndices = theIndices(1:theCount);
end
theIndices = fliplr(theIndices);

result = ep_trim(theSource, theDestination, theIndices);

if nargout > 0, theResult = result; end
