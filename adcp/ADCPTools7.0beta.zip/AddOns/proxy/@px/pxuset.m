function theResult = PXUSet(self, theUserData)

% PXUSet -- Set/Get the UserData associated with self.
%  PXUSet(self) returns the 'UserData' associated with
%   self, a "px" object.
%  PXUSet(self, theUserData) sets the 'UserData' associated
%   with self to theUserData.
%  PXUSet (no argument) shows help.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 04-Apr-1997 14:37:01.

switch nargin
case 0
   help(mfilename), return
case 1
otherwise
   self(:) = theUserData;
end

result = self(:);

switch nargout
case 0
otherwise
   theResult = result;
end
