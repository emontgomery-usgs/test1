function theResult = UnNest(theCellArray)

% UnNest -- Un-nest cells.
%  UnNest(theCellArray) un-nests theCellArray and
%   returns a column cell-array of the non-cell
%   contents of theCellArray.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 10-Apr-1997 11:05:13.

if nargin < 1, help(mfilename), return, end

if ~iscell(theCellArray)
   theCellArray = {theCellArray};
end

result = cell(1, 0);

for i = 1:prod(size(theCellArray))
   c = theCellArray{i};
   if iscell(c)
      c = unnest(c);
     else
      c = {c};
   end
   result = [result; c];
end

if nargout > 0
   theResult = result;
  else
   disp(result)
end
