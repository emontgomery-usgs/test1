function status = PXZoom(theFactor, theAxes, theDirection)

% PXZoom -- No help available.
% PXZoom -- Zoom the limits of an axes.
%  PXZoom(theFactor, theAxes, 'theDirection') zooms the limits
%   of theAxes by theFactor along theDirection ('x' or 'y').
%   TheFactor defaults to 2, meaning to zoom in by a factor
%   of 2.  Its inverse is 0.5.  If theFactor is 0, theAxes is
%   returned to its 'auto' mode.  TheAxes defaults to all axes
%   in the current figure.  This routine affects only the x and
%   y directions.
%  PXZoom(theFactor, 'theDirection') executes
%   PXZoom(theFactor, [], 'theDirection'), which zooms all axes
%   along theDirection ('x' or 'y').
 
% Copyright (C) 1996 Dr. Charles R. Denham, ZYDECO.
% All Rights Reserved.

if nargout > 0, status = 0; end

if nargin < 1, theFactor = 2; end
if nargin < 2, theAxes = []; end
if nargin < 3, theDirection = 'xy'; end

if isstr(theAxes)
   theDirection = theAxes;
   theAxes = [];
end

if isempty(theAxes)
   theAxes = findobj(gcf, 'Type', 'axes');
end

if ~isempty(theAxes)
   theAxes = flipud(theAxes);
   for i = 1:length(theAxes)
      axes(theAxes(i))
      zoomsafe(theFactor, theDirection)
   end
end

figure(gcf)
