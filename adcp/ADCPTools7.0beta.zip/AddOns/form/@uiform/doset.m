function [theFunction, theInputs, theOutputs] = doset(self, varargin)

% uiform/doset -- Set/get fields of a UIForm.
%  doset(self, ...) sets the fields of self, a "uiform",
%   to the given {varargin} values, in the sequence
%   supplied, from top to bottom.
%  [theFunction, theInputs, theOutputs] = doset(self)
%   returns theFunction and the input and output fields
%   of self, a "uiform".
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 22-May-1997 11:07:38.

if nargin < 1, help(mfilename), return, end

if nargin > 1
   while iscell(varargin{1})
      varargin = varargin{1};
   end
  else
   theFunction = '';
   theIns = cell(0, 0);
   theOuts = cell(0, 0);
end

theFigure = self.itSelf;

f = findobj(theFigure, 'Type', 'uicontrol', 'Style', 'frame');
c = get(f, 'UserData');

theOutputFlag = 0;
k = 0;
for i = 1:length(c)
   theTag = get(c(i), 'Tag');
   if i == 1
      theFcn = theTag;
     elseif strcmp(theTag, '=')
      theOutputFlag = 1;
     elseif ~isempty(theTag)
      k = k + 1;
      if nargin > 1
         switch class(varargin{k})
         case 'cell'
            theString = varargin{k};
            for index = 1:length(theString)
               switch class(theString{index})
               case 'char'
                  theString{index} = ['''' theString{index} ''''];
               case 'double'
                  theString{index} = mat2str(theString{index});
               otherwise
               end
            end
         case 'char'
            theString = ['''' varargin{k} ''''];
         case 'double'
            theString = mat2str(varargin{k});
         otherwise
         end
         theStyle = get(c(i), 'Style');
         switch theStyle   % Set the controls.
         case 'pushbutton'
         case {'checkbox', 'radiobutton'}
            theValue = 0;
            switch class(theString)
            case 'cell'
               theValue = eval(theString{1});
            case 'char'
               theValue = eval(theString);
            otherwise
            end
            set(c(i), 'Value', theValue, 'String', '0 or 1')
         case 'popupmenu'
            s = get(c(i), {'String'});
            if isequal(s, {'-'})
               set(c(i), 'String', theString, 'Value', 1)
            end
         otherwise
            set(c(i), 'String', theString)
         end
      elseif theOutputFlag == 0
         theStyle = get(c(i), 'Style');
         switch lower(theStyle)
         case 'pushbutton'
            theString = get(c(i), 'UserData');
            theValue = get(c(i), 'Value');
         case 'checkbox'
            theString = 'checkbox';
            theValue = get(c(i), 'Value');
         case 'radiobutton'
            theString = 'radiobutton';
            theValue = get(c(i), 'Value');
         case 'popupmenu'
            theString = get(c(i), {'String'});
            theString = theString{1};
            for index = 1:length(theString)
               theString{index} = eval(theString{index});
            end
            theValue = get(c(i), 'Value');
         otherwise
            theString = get(c(i), 'String');
            theString = eval(theString);
            theValue = get(c(i), 'Value');
         end
         if isempty(theIns)
            theIns = {theString, theValue};
         else
            theIns = [theIns; {theString, theValue}];
         end
      elseif theOutputFlag == 1
         theValue = get(c(i), 'Value');
         theString = eval(get(c(i), 'String'));
         if isempty(theOuts)
            theOuts = {theString theValue};
         else
            theOuts = [theOuts; {theString theValue}];
         end
      end
      if nargin > 1 & k >= length(varargin), break, end
   end
end

if nargout > 0
   theFunction = '';
   theInputs = [];
   theOutputs = [];
   if nargin < 2
      theFunction = theFcn;
      theInputs = theIns;
      theOutputs = theOuts;
   end
  elseif nargin < 2
   theFunction = theFcn;
   theInputFields = theIns
   theOutputFields = theOuts
end
