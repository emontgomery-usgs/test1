function theResult = PXDelete(self)

% PXDelete -- Delete a "px" object.
%  PXDelete(self) deletes self, a "px" object.  Handles
%   registered with self.itsHandles are also deleted.
%   The empty-matrix [] is returned.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 22-Jul-1997 07:50:52.

h = pxget(self, 'itsHandles');
if any(h), delete(h); end

delete(self.itSelf)

if nargout > 0, theResult = []; end
