function theResult = EP_Trim(theSource, theDestination, theIndices)

% EP_Trim -- Trim an EPIC file.
%  EP_Trim('theSource', 'theDestination', theIndices) writes
%   the time-records associated with theIndices (base-1) in
%   'theSource' to 'theDestination'.  Other entities are
%   written without change.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
 
% Version of 13-May-1997 15:06:13.

result = -1;
if nargout > 0, theResult = result; end

if nargin < 2, help(mfilename), return, end

fcopy(theSource, theDestination)

dst = epic(theDestination, 'write');
if isempty(dst), return, end

if nargin < 3, theIndices = 1:size(dst('time')); end

vartrim(dst, theIndices)

dst = close(dst);

if isempty(dst) & nargout > 0, theResult = []; end
