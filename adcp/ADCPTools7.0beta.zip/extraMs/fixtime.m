function[newj] = fixtime(filename, fastslow)  

%function[newj] = fixtime(filename, fastslow)  
%fixes the time for any netcdf file that has julian time called "TIM"
%filename = name of netcdf file
%fastslow = desired adjustment to time in seconds

% Written by Jessica M. Cote
% for the U.S. Geological Survey
% Coastal and Marine Geology Program
% Woods Hole, MA
% http://woodshole.er.usgs.gov/
% Please report bugs to jcote@usgs.gov

h = netcdf(filename,'write')
if isempty(h),return, end

ftime = h{'TIM'};
jtime = ftime(:);
if nargin < 2
   fastslow = h{'TIM'}.slow_by(:); %in sec
end
%needs to be in fraction of a day
tadj = (fastslow/3600)/24;

newj = jtime + tadj;

ftime(:) = newj(:);
close(h)